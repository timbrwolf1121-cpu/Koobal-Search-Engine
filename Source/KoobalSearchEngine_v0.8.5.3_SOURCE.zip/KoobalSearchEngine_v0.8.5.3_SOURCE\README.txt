﻿Koobal Search Engine v0.8.5.3 — courtesy source snapshot
Assembly 0.8.5.5. Essential C# + csproj + LICENSE only.
Build against KSP 1.12 Managed + Harmony 2. See root README on GitHub.
