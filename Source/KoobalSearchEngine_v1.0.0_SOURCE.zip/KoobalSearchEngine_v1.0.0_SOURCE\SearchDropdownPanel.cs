using System;

using System.Collections.Generic;

using KSP.UI.Screens;

using TMPro;

using UnityEngine;

using UnityEngine.EventSystems;

using UnityEngine.UI;



namespace PartSearchSuggest

{

    internal sealed class SearchDropdownPanel : MonoBehaviour

    {

        // Typography tuned for 1080p readability (v0.8.5.1).
        private const float PrimaryFontSize = 14f;
        private const float SubtitleFontSize = 12f;
        private const float HeaderFontSize = 13f;
        private const float HeaderIconFontSize = 10f;

        private const float RowHeight = 34f;
        private const float RowHeightWithSubtitle = 48f;
        private const float CategoryIconSize = 20f;
        private const float CategoryIconPadding = 4f;
        private const float TitleLineHeight = 20f;
        private const float SubtitleLineHeight = 16f;
        private const float HeaderHeight = 20f;
        private const float CloseButtonSize = 14f;
        private const float HistoryDismissButtonSize = 16f;
        private const float MaxPanelHeight = 420f;
        private const float PanelPadding = 4f;
        private const float GapBelowSearchField = 2f;

        private static readonly Color PrimaryTextColor = new Color(0.96f, 0.98f, 1f, 1f);
        private static readonly Color SubtitleTextColor = new Color(0.74f, 0.86f, 0.98f, 1f);
        private static readonly Color HeaderTextColor = new Color(0.88f, 0.92f, 0.98f, 1f);
        private static readonly Color HeaderIconTextColor = new Color(0.95f, 0.92f, 0.92f, 1f);
        private static readonly Color PanelBackgroundColor = new Color(0.08f, 0.11f, 0.15f, 1f);

        private static Sprite _whiteSprite;

        private static Sprite _trashcanSprite;



        private RectTransform _rootRect;

        private RectTransform _panelRect;

        private RectTransform _viewportRect;

        private RectTransform _rowsContentRect;

        private LayoutElement _scrollAreaLayout;

        private ScrollRect _scrollRect;

        private PointerEventData _wheelPointerEvent;

        private RectTransform _searchFieldRect;

        private Canvas _referenceCanvas;

        /// <summary>Dedicated overlay canvas — never parented under stock editor UI.</summary>
        private Canvas _overlayCanvas;

        private CanvasGroup _overlayCanvasGroup;

        private TextMeshProUGUI _headerLabel;

        private GameObject _headerRow;

        private GameObject _brandingFooter;

        private LayoutElement _brandingFooterLayout;

        private GameObject _brandingContentHost;

        private GameObject _clearHistoryButton;

        private readonly List<GameObject> _rowObjects = new List<GameObject>();

        private bool _dropdownOpen;

        private bool _reserveCategoryIconRail;

        private float CategoryIconRailWidth => CategoryIconSize + CategoryIconPadding * 2f;



        public event Action<PartSuggestion> OnSuggestionChosen;

        public event Action OnDismissed;

        public event Action OnClearHistoryRequested;

        public event Action<string> OnHistoryItemDismissed;



        public bool IsVisible =>
            _dropdownOpen
            && _rootRect != null
            && _overlayCanvasGroup != null
            && _overlayCanvasGroup.alpha > 0.01f;



        public bool IsDropdownOpen => _dropdownOpen;



        public static SearchDropdownPanel Create(RectTransform searchFieldRect)

        {

            Canvas referenceCanvas = searchFieldRect != null
                ? searchFieldRect.GetComponentInParent<Canvas>()
                : null;

            // Own canvas root — never SetParent under stock layout/CanvasScaler trees.
            // Editor-scene only: do NOT DontDestroyOnLoad. A DDOL Overlay + CanvasScaler
            // surviving into MAINMENU/SPACECENTER broke stock UI scaling before save load.
            // Always ScreenSpaceOverlay + high sort order so we do not depend on the stock
            // UI camera (copying ScreenSpaceCamera made WorldToScreenPoint miss and hid rows).
            GameObject root = new GameObject("KoobalSearchEngine_Overlay", typeof(RectTransform));

            Canvas overlayCanvas = root.AddComponent<Canvas>();
            overlayCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            overlayCanvas.overrideSorting = true;
            overlayCanvas.sortingOrder = 32000;
            overlayCanvas.pixelPerfect = false;
            // Disabled until Show — an active Overlay scaler must not exist outside editor use.
            overlayCanvas.enabled = false;

            // Fixed reference scaler for OUR canvas only — never mutate stock CanvasScaler,
            // never copy live stock scaleFactor (that leaked into main-menu UI when DDOL).
            CanvasScaler ourScaler = root.AddComponent<CanvasScaler>();
            ourScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            ourScaler.referenceResolution = new Vector2(1920f, 1080f);
            ourScaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            ourScaler.matchWidthOrHeight = 1f;

            root.AddComponent<GraphicRaycaster>();

            RectTransform rootRect = root.GetComponent<RectTransform>();
            StretchFull(rootRect);
            rootRect.localScale = Vector3.one;

            CanvasGroup canvasGroup = root.AddComponent<CanvasGroup>();
            canvasGroup.blocksRaycasts = false;
            canvasGroup.interactable = false;
            canvasGroup.alpha = 0f;

            SearchDropdownPanel panel = root.AddComponent<SearchDropdownPanel>();
            panel._overlayCanvasGroup = canvasGroup;
            panel.Build(searchFieldRect, rootRect, referenceCanvas, overlayCanvas);
            panel.SetOverlayVisible(false);
            return panel;

        }



        private void Build(
            RectTransform searchFieldRect,
            RectTransform rootRect,
            Canvas referenceCanvas,
            Canvas overlayCanvas)

        {

            _rootRect = rootRect;

            _searchFieldRect = searchFieldRect;

            _referenceCanvas = referenceCanvas;

            _overlayCanvas = overlayCanvas;



            CreateDimBlocker();

            CreateDropdownPanel();

        }



        private void CreateDimBlocker()
        {
            GameObject blocker = new GameObject("DimBlocker", typeof(RectTransform));
            blocker.transform.SetParent(_rootRect, false);
            blocker.transform.SetSiblingIndex(0);
            StretchFull(blocker.GetComponent<RectTransform>());

            Image blockerImage = blocker.AddComponent<Image>();
            blockerImage.sprite = GetWhiteSprite();
            blockerImage.color = new Color(0f, 0f, 0f, 0f);
            blockerImage.raycastTarget = true;

            // Do NOT use Button/Selectable — a full-screen Selectable steals Left/Right from the
            // search TMP_InputField via Selectable.OnMove even when navigation is None on rows.
            PointerClickRelay clickHandler = blocker.AddComponent<PointerClickRelay>();
            clickHandler.Initialize(RequestDismiss);
        }

        private sealed class PointerClickRelay : MonoBehaviour, IPointerClickHandler
        {
            private Action _onClick;

            internal void Initialize(Action onClick)
            {
                _onClick = onClick;
            }

            public void OnPointerClick(PointerEventData eventData)
            {
                if (eventData != null && eventData.button != PointerEventData.InputButton.Left)
                {
                    return;
                }

                _onClick?.Invoke();
            }
        }

        private sealed class RowHoverClickHandler : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
        {
            private Image _image;
            private Color _normal;
            private Color _hover;
            private Action _onClick;

            internal void Initialize(Image image, Color normal, Color hover, Action onClick)
            {
                _image = image;
                _normal = normal;
                _hover = hover;
                _onClick = onClick;
            }

            public void OnPointerEnter(PointerEventData eventData)
            {
                if (_image != null)
                {
                    _image.color = _hover;
                }
            }

            public void OnPointerExit(PointerEventData eventData)
            {
                if (_image != null)
                {
                    _image.color = _normal;
                }
            }

            public void OnPointerClick(PointerEventData eventData)
            {
                if (eventData != null && eventData.button != PointerEventData.InputButton.Left)
                {
                    return;
                }

                // History X is a child with its own handler. If Unity delivers the click to
                // the row as well, skip apply so dismiss does not also run the search.
                if (eventData != null)
                {
                    GameObject hit = eventData.pointerCurrentRaycast.gameObject;
                    if (hit != null && hit != gameObject)
                    {
                        RowHoverClickHandler nested = hit.GetComponentInParent<RowHoverClickHandler>();
                        if (nested != null && nested != this)
                        {
                            return;
                        }
                    }
                }

                _onClick?.Invoke();
            }
        }



        private void CreateDropdownPanel()

        {

            GameObject panelObject = new GameObject("DropdownPanel", typeof(RectTransform));

            panelObject.transform.SetParent(_rootRect, false);

            _panelRect = panelObject.GetComponent<RectTransform>();



            Image background = panelObject.AddComponent<Image>();

            background.sprite = GetWhiteSprite();

            background.color = PanelBackgroundColor;

            background.raycastTarget = true;



            VerticalLayoutGroup layout = panelObject.AddComponent<VerticalLayoutGroup>();

            layout.childAlignment = TextAnchor.UpperCenter;

            layout.childControlHeight = true;

            layout.childControlWidth = true;

            layout.childForceExpandHeight = false;

            layout.childForceExpandWidth = true;

            layout.spacing = 0f;

            layout.padding = new RectOffset(3, 3, 2, 2);



            CreateHeader(panelObject.transform);

            CreateScrollArea(panelObject.transform);

            CreateBrandingFooter(panelObject.transform);

            AttachScrollEvents(panelObject);



            PositionPanelBelowSearchField();

        }



        /// <summary>
        /// KSP stock pattern (CraftEntry / DirectoryController): EventTrigger Scroll on
        /// raycast targets forwards wheel input to ScrollRect.OnScroll because the editor
        /// does not reliably deliver IScrollHandler events while the search field is focused.
        /// </summary>
        private void AttachScrollEvents(GameObject panelObject)

        {

            AttachScrollEvent(panelObject);

            if (_viewportRect != null)

            {

                AttachScrollEvent(_viewportRect.gameObject);

            }



            Transform header = panelObject.transform.Find("Header");

            if (header != null)

            {

                AttachScrollEvent(header.gameObject);

            }

        }



        private void AttachScrollEvent(GameObject target)

        {

            if (target == null)

            {

                return;

            }



            EventTrigger trigger = target.GetComponent<EventTrigger>();

            if (trigger == null)

            {

                trigger = target.AddComponent<EventTrigger>();

            }



            for (int i = 0; i < trigger.triggers.Count; i++)

            {

                if (trigger.triggers[i].eventID == EventTriggerType.Scroll)

                {

                    return;

                }

            }



            EventTrigger.Entry scrollEntry = new EventTrigger.Entry

            {

                eventID = EventTriggerType.Scroll

            };

            scrollEntry.callback.AddListener(OnScrollEventTriggered);

            trigger.triggers.Add(scrollEntry);

        }



        private void OnScrollEventTriggered(BaseEventData baseEventData)

        {

            PointerEventData pointerData = baseEventData as PointerEventData;

            if (pointerData == null)

            {

                return;

            }



            if (ForwardScroll(pointerData))

            {

                pointerData.Use();

            }

        }



        private void CreateBrandingFooter(Transform parent)
        {
            GameObject footer = new GameObject("BrandingFooter", typeof(RectTransform));
            footer.transform.SetParent(parent, false);
            _brandingFooter = footer;

            // Footer is only a fixed-height panel child. Do NOT put a LayoutGroup on the
            // footer itself — that fights StretchFull on the content host and collapses
            // the wordmark to preferred text width (left drift with history / resize).
            _brandingFooterLayout = footer.AddComponent<LayoutElement>();
            _brandingFooterLayout.flexibleHeight = 0f;
            _brandingFooterLayout.flexibleWidth = 1f;
            _brandingFooterLayout.minWidth = 0f;

            Image footerBackground = footer.AddComponent<Image>();
            footerBackground.sprite = GetWhiteSprite();
            footerBackground.color = new Color(1f, 1f, 1f, 0f);
            footerBackground.raycastTarget = false;

            GameObject contentHost = new GameObject("BrandingContent", typeof(RectTransform));
            contentHost.transform.SetParent(footer.transform, false);
            _brandingContentHost = contentHost;

            // Stretch host always tracks footer size (history rows, panel height, rail width).
            ApplyBrandingContentHostStretch();

            // Intrinsic-width children + MiddleCenter = logo stays centered in the full host.
            VerticalLayoutGroup layout = contentHost.AddComponent<VerticalLayoutGroup>();
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = false;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = false;
            layout.childForceExpandHeight = false;
            layout.spacing = 0f;
            layout.padding = new RectOffset(4, 4, 2, 2);

            UpdateBrandingFooterVisuals();
            footer.SetActive(false);
        }

        private void ApplyBrandingContentHostStretch()
        {
            if (_brandingContentHost == null)
            {
                return;
            }

            RectTransform hostRect = _brandingContentHost.transform as RectTransform;
            if (hostRect == null)
            {
                return;
            }

            StretchFull(hostRect);
            hostRect.offsetMin = new Vector2(4f, 2f);
            hostRect.offsetMax = new Vector2(-4f, -2f);
        }

        private void UpdateBrandingFooterVisuals()
        {
            if (_brandingFooterLayout == null || _brandingContentHost == null)
            {
                return;
            }

            float footerHeight = BrandingSettings.FooterHeight;
            _brandingFooterLayout.minHeight = footerHeight;
            _brandingFooterLayout.preferredHeight = footerHeight;

            // DestroyImmediate so deferred Destroy leftovers cannot leave a left-anchored
            // sibling in the layout pass that runs later in Show().
            for (int i = _brandingContentHost.transform.childCount - 1; i >= 0; i--)
            {
                DestroyImmediate(_brandingContentHost.transform.GetChild(i).gameObject);
            }

            ApplyBrandingContentHostStretch();

            TMP_FontAsset font = _headerLabel != null ? _headerLabel.font : null;
            if (BrandingSettings.DropdownBranding == DropdownBrandingVariant.FullTagline)
            {
                KoobalWordmarkBuilder.BuildFullTagline(_brandingContentHost.transform, font);
            }
            else
            {
                KoobalWordmarkBuilder.BuildWordmarkOnly(_brandingContentHost.transform, font);
            }

            RectTransform hostRect = _brandingContentHost.transform as RectTransform;
            if (hostRect != null)
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(hostRect);
            }
        }

        private void RebuildBrandingFooterLayout()
        {
            if (_brandingFooter == null || !_brandingFooter.activeSelf)
            {
                return;
            }

            // Re-assert stretch after panel sizeDelta / pivot changes (dropdown move-down,
            // category rail, history height) so the host never inherits a left-sized rect.
            ApplyBrandingContentHostStretch();

            RectTransform hostRect = _brandingContentHost != null
                ? _brandingContentHost.transform as RectTransform
                : null;
            if (hostRect != null)
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(hostRect);
            }
        }

        private void CreateHeader(Transform parent)

        {

            GameObject header = new GameObject("Header", typeof(RectTransform));

            header.transform.SetParent(parent, false);

            _headerRow = header;



            LayoutElement headerLayout = header.AddComponent<LayoutElement>();

            headerLayout.minHeight = HeaderHeight;

            headerLayout.preferredHeight = HeaderHeight;



            Image headerBackground = header.AddComponent<Image>();

            headerBackground.sprite = GetWhiteSprite();

            headerBackground.color = new Color(0.1f, 0.13f, 0.18f, 1f);

            headerBackground.raycastTarget = true;

            header.AddComponent<RectMask2D>();



            HorizontalLayoutGroup headerGroup = header.AddComponent<HorizontalLayoutGroup>();

            headerGroup.childAlignment = TextAnchor.MiddleCenter;

            headerGroup.spacing = 1f;

            headerGroup.padding = new RectOffset(3, 1, 1, 1);

            headerGroup.childControlWidth = true;

            headerGroup.childControlHeight = true;

            headerGroup.childForceExpandWidth = false;

            headerGroup.childForceExpandHeight = false;



            _clearHistoryButton = CreateHeaderIconButton(

                header.transform,

                "ClearHistoryButton",

                null,

                new Color(0.18f, 0.22f, 0.28f, 1f),

                new Color(0.35f, 0.28f, 0.18f, 1f),

                new Color(0.28f, 0.22f, 0.15f, 1f),

                RequestClearHistory,

                GetTrashcanSprite());

            _clearHistoryButton.SetActive(false);

            UiTooltipHelper.AttachTextTooltip(_clearHistoryButton, "Clear history");



            GameObject labelObject = new GameObject("HeaderLabel", typeof(RectTransform));

            labelObject.transform.SetParent(header.transform, false);



            LayoutElement labelLayout = labelObject.AddComponent<LayoutElement>();

            labelLayout.flexibleWidth = 1f;

            labelLayout.minHeight = 0f;

            labelLayout.preferredHeight = HeaderHeight;



            _headerLabel = labelObject.AddComponent<TextMeshProUGUI>();

            _headerLabel.fontSize = HeaderFontSize;

            _headerLabel.lineSpacing = -2f;

            _headerLabel.margin = Vector4.zero;

            _headerLabel.color = HeaderTextColor;

            _headerLabel.text = "Suggestions";

            _headerLabel.alignment = TextAlignmentOptions.Center;

            _headerLabel.enableWordWrapping = false;

            _headerLabel.overflowMode = TextOverflowModes.Overflow;

            _headerLabel.raycastTarget = false;



            CreateHeaderIconButton(

                header.transform,

                "CloseButton",

                "X",

                new Color(0.18f, 0.22f, 0.28f, 1f),

                new Color(0.35f, 0.2f, 0.2f, 1f),

                new Color(0.28f, 0.15f, 0.15f, 1f),

                RequestDismiss);

        }



        private GameObject CreateHeaderIconButton(

            Transform parent,

            string objectName,

            string labelText,

            Color normalColor,

            Color highlightedColor,

            Color pressedColor,

            UnityEngine.Events.UnityAction onClick,

            Sprite iconSprite = null)

        {

            GameObject buttonObject = new GameObject(objectName, typeof(RectTransform));

            buttonObject.transform.SetParent(parent, false);



            LayoutElement buttonLayout = buttonObject.AddComponent<LayoutElement>();

            buttonLayout.minWidth = CloseButtonSize;

            buttonLayout.preferredWidth = CloseButtonSize;

            buttonLayout.minHeight = CloseButtonSize;

            buttonLayout.preferredHeight = CloseButtonSize;



            Image buttonImage = buttonObject.AddComponent<Image>();

            buttonImage.sprite = GetWhiteSprite();

            buttonImage.color = normalColor;

            buttonImage.raycastTarget = true;

            // Non-Selectable: Button.OnPointerDown would steal EventSystem selection from the
            // search field and re-trigger ShowSuggestions while hovering history / clicking X.
            RowHoverClickHandler hoverClick = buttonObject.AddComponent<RowHoverClickHandler>();
            hoverClick.Initialize(buttonImage, normalColor, highlightedColor, () => onClick());



            if (iconSprite != null)

            {

                GameObject iconObject = new GameObject("Icon", typeof(RectTransform));

                iconObject.transform.SetParent(buttonObject.transform, false);



                RectTransform iconRect = iconObject.GetComponent<RectTransform>();

                iconRect.anchorMin = new Vector2(0.5f, 0.5f);

                iconRect.anchorMax = new Vector2(0.5f, 0.5f);

                iconRect.pivot = new Vector2(0.5f, 0.5f);

                iconRect.sizeDelta = new Vector2(10f, 10f);

                iconRect.anchoredPosition = Vector2.zero;



                Image iconImage = iconObject.AddComponent<Image>();

                iconImage.sprite = iconSprite;

                iconImage.color = HeaderIconTextColor;

                iconImage.raycastTarget = false;

                iconImage.preserveAspect = true;

            }

            else

            {

                GameObject labelObject = new GameObject("Label", typeof(RectTransform));

                labelObject.transform.SetParent(buttonObject.transform, false);

                StretchFull(labelObject.GetComponent<RectTransform>());



                TextMeshProUGUI label = labelObject.AddComponent<TextMeshProUGUI>();

                label.text = labelText;

                label.fontSize = HeaderIconFontSize;

                label.lineSpacing = -2f;

                label.margin = Vector4.zero;

                label.fontStyle = FontStyles.Bold;

                label.alignment = TextAlignmentOptions.Center;

                label.color = HeaderIconTextColor;

                label.raycastTarget = false;

            }



            return buttonObject;

        }



        private void CreateScrollArea(Transform parent)

        {

            // Height cap lives on a wrapper with LayoutElement only. ScrollRect also implements
            // ILayoutElement and reports full content height; on the same GameObject that wins
            // over our cap and the panel grows to fit every row (no internal scroll).
            GameObject scrollWrapper = new GameObject("ScrollAreaWrapper", typeof(RectTransform));

            scrollWrapper.transform.SetParent(parent, false);



            _scrollAreaLayout = scrollWrapper.AddComponent<LayoutElement>();

            _scrollAreaLayout.flexibleHeight = 0f;

            _scrollAreaLayout.minHeight = 0f;



            GameObject scrollArea = new GameObject("ScrollArea", typeof(RectTransform));

            scrollArea.transform.SetParent(scrollWrapper.transform, false);

            StretchFull(scrollArea.GetComponent<RectTransform>());



            Image scrollAreaBackground = scrollArea.AddComponent<Image>();

            scrollAreaBackground.sprite = GetWhiteSprite();

            scrollAreaBackground.color = PanelBackgroundColor;

            scrollAreaBackground.raycastTarget = false;



            GameObject viewport = new GameObject("Viewport", typeof(RectTransform));

            viewport.transform.SetParent(scrollArea.transform, false);

            _viewportRect = viewport.GetComponent<RectTransform>();

            StretchFull(_viewportRect);



            Image viewportImage = viewport.AddComponent<Image>();

            viewportImage.sprite = GetWhiteSprite();

            viewportImage.color = PanelBackgroundColor;

            viewportImage.raycastTarget = true;

            viewport.AddComponent<RectMask2D>();



            GameObject content = new GameObject("Content", typeof(RectTransform));

            content.transform.SetParent(viewport.transform, false);

            _rowsContentRect = content.GetComponent<RectTransform>();

            _rowsContentRect.anchorMin = new Vector2(0f, 1f);

            _rowsContentRect.anchorMax = new Vector2(1f, 1f);

            _rowsContentRect.pivot = new Vector2(0.5f, 1f);

            _rowsContentRect.anchoredPosition = Vector2.zero;

            _rowsContentRect.sizeDelta = new Vector2(0f, 0f);



            VerticalLayoutGroup contentLayout = content.AddComponent<VerticalLayoutGroup>();

            contentLayout.childAlignment = TextAnchor.UpperCenter;

            contentLayout.childControlHeight = true;

            contentLayout.childControlWidth = true;

            contentLayout.childForceExpandHeight = false;

            contentLayout.childForceExpandWidth = true;

            contentLayout.spacing = 0f;



            ContentSizeFitter contentFitter = content.AddComponent<ContentSizeFitter>();

            contentFitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;

            contentFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;



            _scrollRect = scrollArea.AddComponent<ScrollRect>();

            _scrollRect.viewport = _viewportRect;

            _scrollRect.content = _rowsContentRect;

            _scrollRect.horizontal = false;

            _scrollRect.vertical = true;

            _scrollRect.movementType = ScrollRect.MovementType.Clamped;

            _scrollRect.scrollSensitivity = 40f;

            _scrollRect.inertia = true;

        }



        private void Update()

        {

            if (!IsVisible || _scrollRect == null || !_scrollRect.enabled || !_scrollRect.vertical)

            {

                return;

            }



            float scrollDelta = Input.mouseScrollDelta.y;

            if (Mathf.Abs(scrollDelta) < 0.001f)

            {

                return;

            }



            if (!IsPointerOverScrollTarget())

            {

                return;

            }



            ForwardScrollFromMouseWheel(scrollDelta);

        }



        private void ForwardScrollFromMouseWheel(float scrollDelta)
        {
            if (_wheelPointerEvent == null)
            {
                _wheelPointerEvent = new PointerEventData(EventSystem.current);
            }

            _wheelPointerEvent.Reset();
            _wheelPointerEvent.scrollDelta = new Vector2(0f, scrollDelta);
            ForwardScroll(_wheelPointerEvent);
        }



        private bool ForwardScroll(PointerEventData eventData)

        {

            if (_scrollRect == null || eventData == null || !_scrollRect.enabled || !_scrollRect.vertical)

            {

                return false;

            }



            if (!CanScrollContent())

            {

                return false;

            }



            _scrollRect.OnScroll(eventData);

            return true;

        }



        private bool CanScrollContent()

        {

            if (_rowsContentRect == null || _viewportRect == null)

            {

                return false;

            }



            return _rowsContentRect.rect.height > _viewportRect.rect.height + 0.5f;

        }



        private bool IsPointerOverScrollTarget()

        {

            return IsPointerOverRect(_panelRect);

        }



        private bool IsPointerOverRect(RectTransform rect)

        {

            if (rect == null)

            {

                return false;

            }



            return RectTransformUtility.RectangleContainsScreenPoint(rect, Input.mousePosition, GetEventCamera());

        }




        private static RectTransform FindOverlayParent(RectTransform searchFieldRect)

        {

            RectTransform best = searchFieldRect.parent as RectTransform;

            RectTransform current = best;

            RectTransform bestWithoutLayout = null;

            while (current != null)

            {

                if (current.rect.height >= 150f)

                {
                    // Prefer a tall parent that will not reflow siblings when we StretchFull.
                    if (current.GetComponent<LayoutGroup>() == null
                        && current.GetComponent<ContentSizeFitter>() == null)
                    {
                        bestWithoutLayout = current;
                    }

                    best = current;

                }



                current = current.parent as RectTransform;

            }



            return bestWithoutLayout ?? best ?? searchFieldRect;

        }



        private static void StretchFull(RectTransform rect)

        {

            rect.anchorMin = Vector2.zero;

            rect.anchorMax = Vector2.one;

            rect.offsetMin = Vector2.zero;

            rect.offsetMax = Vector2.zero;

            rect.pivot = new Vector2(0.5f, 0.5f);

        }



        private static Sprite GetWhiteSprite()

        {

            if (_whiteSprite != null)

            {

                return _whiteSprite;

            }



            Texture2D texture = Texture2D.whiteTexture;

            _whiteSprite = Sprite.Create(

                texture,

                new Rect(0f, 0f, texture.width, texture.height),

                new Vector2(0.5f, 0.5f));

            return _whiteSprite;

        }



        /// <summary>

        /// Programmatic 16x16 trashcan. Stock LiberationSans lacks U+1F5D1,

        /// and Squad GameData has no suitable delete/trash UI sprite at this size.

        /// </summary>

        private static Sprite GetTrashcanSprite()

        {

            if (_trashcanSprite != null)

            {

                return _trashcanSprite;

            }



            const int size = 16;

            Texture2D texture = new Texture2D(size, size, TextureFormat.ARGB32, false);

            texture.filterMode = FilterMode.Point;

            texture.wrapMode = TextureWrapMode.Clamp;

            texture.hideFlags = HideFlags.HideAndDontSave;



            Color clear = new Color(0f, 0f, 0f, 0f);

            Color solid = Color.white;

            Color[] pixels = new Color[size * size];

            for (int i = 0; i < pixels.Length; i++)

            {

                pixels[i] = clear;

            }



            // Pixel art (y=0 at bottom). Readable at ~10px on dark header buttons.

            System.Action<int, int> plot = (x, y) =>

            {

                if (x >= 0 && x < size && y >= 0 && y < size)

                {

                    pixels[y * size + x] = solid;

                }

            };



            System.Action<int, int, int> hLine = (x0, x1, y) =>

            {

                for (int x = x0; x <= x1; x++)

                {

                    plot(x, y);

                }

            };



            // Lid handle

            hLine(6, 9, 14);

            hLine(6, 9, 13);

            // Lid

            hLine(3, 12, 12);

            hLine(2, 13, 11);

            // Can body outline + vertical ribs

            for (int y = 3; y <= 10; y++)

            {

                plot(2, y);

                plot(13, y);

                plot(5, y);

                plot(8, y);

                plot(11, y);

            }



            hLine(2, 13, 10);

            hLine(3, 12, 3);

            hLine(4, 11, 2);



            texture.SetPixels(pixels);

            texture.Apply(false, true);



            _trashcanSprite = Sprite.Create(

                texture,

                new Rect(0f, 0f, size, size),

                new Vector2(0.5f, 0.5f),

                100f);

            _trashcanSprite.name = "KoobalTrashcan";

            return _trashcanSprite;

        }



        private void PositionPanelBelowSearchField()
        {
            if (_panelRect == null || _searchFieldRect == null || _rootRect == null)
            {
                return;
            }

            // Ensure overlay root stays active so Overlay canvas rects are valid.
            if (!_rootRect.gameObject.activeSelf)
            {
                _rootRect.gameObject.SetActive(true);
            }

            RectTransform searchParent = _searchFieldRect.parent as RectTransform;
            float railWidth = _reserveCategoryIconRail ? CategoryIconRailWidth : 0f;
            if (searchParent != null && searchParent == _rootRect)
            {
                float textWidth = Mathf.Max(_searchFieldRect.rect.width, 120f);
                float height = _panelRect.sizeDelta.y > 0f ? _panelRect.sizeDelta.y : MaxPanelHeight;
                _panelRect.anchorMin = _searchFieldRect.anchorMin;
                _panelRect.anchorMax = _searchFieldRect.anchorMax;
                if (railWidth > 0f)
                {
                    _panelRect.pivot = new Vector2(0f, 1f);
                    _panelRect.sizeDelta = new Vector2(textWidth + railWidth, height);
                    _panelRect.anchoredPosition = _searchFieldRect.anchoredPosition
                        + new Vector2(-textWidth * 0.5f, -_searchFieldRect.rect.height - GapBelowSearchField);
                }
                else
                {
                    _panelRect.pivot = new Vector2(0.5f, 1f);
                    _panelRect.sizeDelta = new Vector2(textWidth, height);
                    _panelRect.anchoredPosition = _searchFieldRect.anchoredPosition
                        + new Vector2(0f, -_searchFieldRect.rect.height - GapBelowSearchField);
                }

                return;
            }

            Vector3[] corners = new Vector3[4];
            _searchFieldRect.GetWorldCorners(corners);

            // Search field lives on the stock canvas (often ScreenSpaceCamera). Convert with
            // that canvas' camera, then into our Overlay root with a null cam.
            Camera searchCamera = GetSearchFieldCamera();
            Vector2 screenBottomLeft = RectTransformUtility.WorldToScreenPoint(searchCamera, corners[0]);
            Vector2 screenTopRight = RectTransformUtility.WorldToScreenPoint(searchCamera, corners[2]);

            Vector2 localBottomLeft;
            Vector2 localTopRight;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _rootRect,
                screenBottomLeft,
                null,
                out localBottomLeft);
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _rootRect,
                screenTopRight,
                null,
                out localTopRight);

            float textWidthWorld = Mathf.Max(localTopRight.x - localBottomLeft.x, 120f);
            float panelTopY = localBottomLeft.y - GapBelowSearchField;
            float heightWorld = _panelRect.sizeDelta.y > 0f ? _panelRect.sizeDelta.y : MaxPanelHeight;

            _panelRect.anchorMin = new Vector2(0.5f, 0.5f);
            _panelRect.anchorMax = new Vector2(0.5f, 0.5f);
            if (railWidth > 0f)
            {
                _panelRect.pivot = new Vector2(0f, 1f);
                _panelRect.sizeDelta = new Vector2(textWidthWorld + railWidth, heightWorld);
                _panelRect.anchoredPosition = new Vector2(localBottomLeft.x, panelTopY);
            }
            else
            {
                float centerX = (localBottomLeft.x + localTopRight.x) * 0.5f;
                _panelRect.pivot = new Vector2(0.5f, 1f);
                _panelRect.sizeDelta = new Vector2(textWidthWorld, heightWorld);
                _panelRect.anchoredPosition = new Vector2(centerX, panelTopY);
            }

            _panelRect.localScale = Vector3.one;
            _panelRect.gameObject.SetActive(true);
        }



        public void Show(
            IReadOnlyList<PartSuggestion> suggestions,
            bool historyMode,
            bool showClearHistory,
            string headerOverride = null,
            bool showBrandingFooter = false)

        {
            int suggestionCount = suggestions?.Count ?? 0;
            bool brandingOnly = showBrandingFooter && suggestionCount == 0;

            if (suggestionCount == 0 && !showBrandingFooter)
            {
                EditorBootstrap.Log("Show: suggestion count is 0 — not activating dropdown.");
                Hide();
                return;
            }

            bool alreadyOpen = _dropdownOpen;
            _dropdownOpen = true;

            PartsPanelCollapseHelper.NotifyDropdownOpen(true);
            // Collapse only once — refreshing an open dropdown must not re-enter stock panel
            // transition (that hitch is visible while typing).
            if (!alreadyOpen)
            {
                PartsPanelCollapseHelper.Collapse();
            }



            ClearRows();

            _reserveCategoryIconRail = false;
            for (int i = 0; i < suggestionCount; i++)
            {
                if (StockCategorizerIconHelper.SupportsCategoryIconRail(suggestions[i]))
                {
                    _reserveCategoryIconRail = true;
                    break;
                }
            }

            if (_reserveCategoryIconRail)
            {
                StockCategorizerIconHelper.EnsureCacheWarmed(suggestions);
            }

            // Position while root is active (CanvasGroup still alpha 0) so Overlay rects are valid.
            if (_rootRect != null && !_rootRect.gameObject.activeSelf)
            {
                _rootRect.gameObject.SetActive(true);
            }

            if (!alreadyOpen)
            {
                PositionPanelBelowSearchField();
            }

            if (_brandingFooter != null)
            {
                if (showBrandingFooter)
                {
                    UpdateBrandingFooterVisuals();
                }

                _brandingFooter.SetActive(showBrandingFooter);
            }

            if (_headerRow != null)
            {
                _headerRow.SetActive(!brandingOnly);
            }

            UpdateClearHistoryVisibility(showClearHistory && !brandingOnly, historyMode, headerOverride);

            float totalRowHeight = 0f;

            for (int i = 0; i < suggestionCount; i++)
            {
                totalRowHeight += CreateRow(suggestions[i]);
            }

            float headerBlockHeight = brandingOnly ? 0f : HeaderHeight;
            float footerBlockHeight = showBrandingFooter ? BrandingSettings.FooterHeight : 0f;
            float contentHeight = totalRowHeight;
            float viewportHeight = Mathf.Max(
                0f,
                MaxPanelHeight - headerBlockHeight - footerBlockHeight - PanelPadding);
            float visibleContentHeight = brandingOnly
                ? 0f
                : Mathf.Min(contentHeight, viewportHeight);
            float panelHeight = headerBlockHeight
                + footerBlockHeight
                + PanelPadding
                + visibleContentHeight;
            if (brandingOnly)
            {
                panelHeight = footerBlockHeight + PanelPadding;
            }



            float previousHeight = _panelRect != null ? _panelRect.sizeDelta.y : -1f;
            _panelRect.sizeDelta = new Vector2(_panelRect.sizeDelta.x, panelHeight);



            if (_scrollAreaLayout != null)
            {
                _scrollAreaLayout.gameObject.SetActive(!brandingOnly);
                _scrollAreaLayout.minHeight = visibleContentHeight;
                _scrollAreaLayout.preferredHeight = visibleContentHeight;
                _scrollAreaLayout.flexibleHeight = 0f;
            }



            // Force rebuild on first open or height change. Mid-typing refresh skips synchronous
            // layout (Unity updates next frame) so InputField does not hitch.
            bool heightChanged = !alreadyOpen || Mathf.Abs(previousHeight - panelHeight) > 0.5f;
            if (heightChanged)
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(_panelRect);

                if (_rowsContentRect != null)
                {
                    LayoutRebuilder.ForceRebuildLayoutImmediate(_rowsContentRect);
                }
            }

            if (showBrandingFooter)
            {
                RebuildBrandingFooterLayout();
            }

            // Local rebuilds only — never Canvas.ForceUpdateCanvases() and never parent under
            // stock UI (own overlay canvas). Global/stock reflow was shrinking editor UI scale.

            if (_scrollRect != null)
            {
                _scrollRect.enabled = true;
                _scrollRect.verticalNormalizedPosition = 1f;
            }

            PositionPanelBelowSearchField();
            SetOverlayVisible(true);

            if (_panelRect != null)
            {
                _panelRect.gameObject.SetActive(true);
                _panelRect.transform.SetAsLastSibling();
            }

            LogShowState(
                suggestionCount,
                historyMode,
                showClearHistory,
                contentHeight,
                viewportHeight,
                showBrandingFooter);
        }



        private void UpdateClearHistoryVisibility(bool showClearHistory, bool historyMode, string headerOverride = null)

        {

            if (_headerLabel != null)

            {

                if (!string.IsNullOrEmpty(headerOverride))

                {

                    _headerLabel.text = headerOverride;

                }

                else

                {

                    _headerLabel.text = historyMode ? "Recent searches" : "Suggestions";

                }

            }



            if (_clearHistoryButton != null)

            {

                _clearHistoryButton.SetActive(showClearHistory);

            }

        }



        private float GetRectHeight(RectTransform rect)

        {

            return rect != null ? rect.rect.height : 0f;

        }



        private void LogShowState(
            int suggestionCount,
            bool historyMode,
            bool showClearHistory,
            float contentHeight,
            float viewportHeight,
            bool showBrandingFooter)

        {

            if (!DebugSettings.Verbose)
            {
                return;
            }

            Camera eventCamera = GetEventCamera();

            Vector3[] panelCorners = new Vector3[4];

            Vector3[] searchCorners = new Vector3[4];

            _panelRect.GetWorldCorners(panelCorners);

            _searchFieldRect.GetWorldCorners(searchCorners);



            float searchBottomY = searchCorners[0].y;

            float panelTopY = panelCorners[1].y;

            bool overlapsSearch = panelTopY > searchBottomY + 0.5f;



            float actualContentHeight = GetRectHeight(_rowsContentRect);

            float actualViewportHeight = GetRectHeight(_viewportRect);

            float actualScrollAreaHeight = _scrollAreaLayout != null ? GetRectHeight(_scrollAreaLayout.transform as RectTransform) : 0f;

            float actualPanelHeight = GetRectHeight(_panelRect);

            bool scrollable = actualContentHeight > actualViewportHeight + 0.5f;



            Vector2 screenPanelTop = RectTransformUtility.WorldToScreenPoint(eventCamera, panelCorners[1]);

            Vector2 screenPanelBottom = RectTransformUtility.WorldToScreenPoint(eventCamera, panelCorners[0]);



            EditorBootstrap.Log(

                "Show dropdown: count=" + suggestionCount

                + ", history=" + historyMode

                + ", clearHistory=" + showClearHistory

                + ", brandingFooter=" + showBrandingFooter

                + ", panelSize=" + _panelRect.sizeDelta

                + ", panelHeight=" + actualPanelHeight.ToString("F1")

                + ", scrollAreaHeight=" + actualScrollAreaHeight.ToString("F1")

                + ", contentHeight=" + contentHeight.ToString("F1")

                + ", actualContentHeight=" + actualContentHeight.ToString("F1")

                + ", viewportHeight=" + viewportHeight.ToString("F1")

                + ", actualViewportHeight=" + actualViewportHeight.ToString("F1")

                + ", scrollEnabled=" + (_scrollRect != null && _scrollRect.enabled)

                + ", scrollable=" + scrollable

                + ", panelPos=" + _panelRect.anchoredPosition

                + ", overlayParent=" + GetTransformPath(_rootRect != null ? _rootRect.parent as RectTransform : null)

                + ", overlayActive=" + (_rootRect != null && _rootRect.gameObject.activeSelf)

                + ", overlayAlpha=" + (_overlayCanvasGroup != null ? _overlayCanvasGroup.alpha.ToString("F2") : "n/a")

                + ", panelActive=" + (_panelRect != null && _panelRect.gameObject.activeSelf)

                + ", renderMode=" + (_overlayCanvas != null ? _overlayCanvas.renderMode.ToString() : "unknown")

                + ", sortingOrder=" + (_overlayCanvas != null ? _overlayCanvas.sortingOrder.ToString() : "n/a")

                + ", worldCamera=" + (eventCamera != null ? eventCamera.name : "null")

                + ", overlaySibling=" + (_rootRect != null ? _rootRect.GetSiblingIndex().ToString() : "n/a")

                + ", partsPanelCollapsed=" + PartsPanelCollapseHelper.IsCollapsed

                + ", collapseApproach=" + PartsPanelCollapseHelper.Approach

                + ", searchBottomY=" + searchBottomY

                + ", panelTopY=" + panelTopY

                + ", panelScreenTop=" + screenPanelTop

                + ", panelScreenBottom=" + screenPanelBottom

                + ", overlapsSearch=" + overlapsSearch

                + ", panelWorldBL=" + panelCorners[0]

                + ", panelWorldTR=" + panelCorners[2]);

        }



        private static string GetTransformPath(RectTransform rect)

        {

            return rect != null ? rect.name : "null";

        }



        private Camera GetSearchFieldCamera()
        {
            if (_referenceCanvas == null || _referenceCanvas.renderMode == RenderMode.ScreenSpaceOverlay)
            {
                return null;
            }

            return _referenceCanvas.worldCamera;
        }

        private Camera GetEventCamera()
        {
            // Overlay canvas uses null camera for screen↔local conversion.
            if (_overlayCanvas == null || _overlayCanvas.renderMode == RenderMode.ScreenSpaceOverlay)
            {
                return null;
            }

            return _overlayCanvas.worldCamera;
        }

        private void SetOverlayVisible(bool visible)
        {
            if (visible && _rootRect != null && !_rootRect.gameObject.activeSelf)
            {
                _rootRect.gameObject.SetActive(true);
            }

            if (_overlayCanvas != null)
            {
                // Enable canvas only while dropdown is shown — keeps scaler inert otherwise.
                _overlayCanvas.enabled = visible;
                if (visible)
                {
                    _overlayCanvas.overrideSorting = true;
                    _overlayCanvas.sortingOrder = 32000;
                }
            }

            if (_overlayCanvasGroup == null && _rootRect != null)
            {
                _overlayCanvasGroup = _rootRect.GetComponent<CanvasGroup>();
            }

            if (_overlayCanvasGroup != null)
            {
                _overlayCanvasGroup.alpha = visible ? 1f : 0f;
                _overlayCanvasGroup.blocksRaycasts = visible;
                _overlayCanvasGroup.interactable = visible;
            }

            if (!visible && _panelRect != null)
            {
                _panelRect.gameObject.SetActive(false);
            }
        }

        public void HideWithoutHoldNotify()
        {
            _dropdownOpen = false;
            ClearOverlayPointerSelection();
            SetOverlayVisible(false);
        }

        private void ClearOverlayPointerSelection()
        {
            if (EventSystem.current == null || _rootRect == null)
            {
                return;
            }

            GameObject selected = EventSystem.current.currentSelectedGameObject;
            if (selected != null && selected.transform.IsChildOf(_rootRect))
            {
                EventSystem.current.SetSelectedGameObject(null);
            }
        }

        public void Hide()

        {

            if (!_dropdownOpen
                && (_overlayCanvasGroup == null || _overlayCanvasGroup.alpha <= 0.01f))

            {

                EditorBootstrap.Log("Hide dropdown: already hidden — skip Restore.");

                return;

            }



            bool wasOpen = _dropdownOpen;

            _dropdownOpen = false;

            PartsPanelCollapseHelper.NotifyDropdownOpen(false);

            ClearOverlayPointerSelection();



            if (wasOpen)

            {

                EditorBootstrap.Log(

                    "Hide dropdown: closed, collapsed="

                    + PartsPanelCollapseHelper.IsCollapsed

                    + ", approach="

                    + PartsPanelCollapseHelper.Approach

                    + ".");

                PartsPanelCollapseHelper.RestoreIfDropdownClosed(true);
            }

            else

            {

                EditorBootstrap.Log("Hide dropdown: overlay active without open flag — deactivating only.");

            }



            SetOverlayVisible(false);

        }



        private void RequestDismiss()

        {

            Hide();

            OnDismissed?.Invoke();

        }



        private void RequestClearHistory()

        {

            EditorBootstrap.Log("Clear history button clicked.");

            OnClearHistoryRequested?.Invoke();

        }



        private float CreateRow(PartSuggestion suggestion)

        {

            bool hasSubtitle = !suggestion.IsHistory && !string.IsNullOrEmpty(suggestion.MatchReason);

            bool isIconEligible = StockCategorizerIconHelper.SupportsCategoryIconRail(suggestion);

            float textInsetRight = _reserveCategoryIconRail ? CategoryIconRailWidth : 0f;
            if (suggestion.IsHistory)
            {
                textInsetRight = Mathf.Max(textInsetRight, HistoryDismissButtonSize + 6f);
            }

            float rowHeight = hasSubtitle ? RowHeightWithSubtitle : RowHeight;



            GameObject row = new GameObject("Row_" + _rowObjects.Count, typeof(RectTransform));

            row.transform.SetParent(_rowsContentRect, false);



            LayoutElement rowLayout = row.AddComponent<LayoutElement>();

            rowLayout.minHeight = rowHeight;

            rowLayout.preferredHeight = rowHeight;

            rowLayout.flexibleHeight = 0f;



            Image rowImage = row.AddComponent<Image>();

            rowImage.sprite = GetWhiteSprite();

            Color normalColor = suggestion.IsFirstClass

                ? new Color(0.12f, 0.22f, 0.30f, 1f)

                : new Color(0.14f, 0.18f, 0.24f, 1f);

            Color hoverColor = suggestion.IsFirstClass

                ? new Color(0.20f, 0.36f, 0.50f, 1f)

                : new Color(0.22f, 0.34f, 0.48f, 1f);

            rowImage.color = normalColor;

            rowImage.raycastTarget = true;



            string title = suggestion.DisplayText ?? suggestion.QueryText ?? string.Empty;

            CreateRowTextContent(row.transform, title, hasSubtitle, suggestion.MatchReason, textInsetRight);

            bool hasCategoryIcon = false;
            if (isIconEligible && _reserveCategoryIconRail)
            {
                hasCategoryIcon = TryCreateCategoryIconRight(row.transform, suggestion, false);
            }

            if (suggestion.IsHistory)
            {
                CreateHistoryDismissButton(row.transform, suggestion);
            }

            if (!hasCategoryIcon && !suggestion.IsHistory)
            {
                row.AddComponent<RectMask2D>();
            }



            PartSuggestion captured = suggestion;

            RowHoverClickHandler hoverClick = row.AddComponent<RowHoverClickHandler>();
            hoverClick.Initialize(rowImage, normalColor, hoverColor, () => HandleRowPointerClick(captured));

            AttachScrollEvent(row);



            _rowObjects.Add(row);

            return rowHeight;

        }



        private static void ConfigureSuggestionLabel(

            TextMeshProUGUI label,

            float fontSize,

            Color color,

            TextAlignmentOptions alignment)

        {

            label.fontSize = fontSize;

            label.lineSpacing = -2f;

            label.margin = Vector4.zero;

            label.color = color;

            label.alignment = alignment;

            label.enableWordWrapping = false;

            label.enableAutoSizing = false;

            label.overflowMode = TextOverflowModes.Ellipsis;

            label.raycastTarget = false;

        }



        private static TextMeshProUGUI CreateRowLabel(

            Transform parent,

            string objectName,

            float height,

            float fontSize,

            Color color,

            string text,

            TextAlignmentOptions alignment = TextAlignmentOptions.Center)

        {

            GameObject labelObject = new GameObject(objectName, typeof(RectTransform));

            labelObject.transform.SetParent(parent, false);



            LayoutElement labelLayout = labelObject.AddComponent<LayoutElement>();

            labelLayout.minHeight = height;

            labelLayout.preferredHeight = height;

            labelLayout.flexibleHeight = 0f;



            TextMeshProUGUI label = labelObject.AddComponent<TextMeshProUGUI>();

            ConfigureSuggestionLabel(label, fontSize, color, alignment);

            label.text = text ?? string.Empty;

            return label;

        }



        private static void CreateSingleLineRowContent(Transform rowTransform, string title)

        {

            GameObject labelObject = new GameObject("Label", typeof(RectTransform));

            labelObject.transform.SetParent(rowTransform, false);

            StretchFull(labelObject.GetComponent<RectTransform>());



            LayoutElement labelLayout = labelObject.AddComponent<LayoutElement>();

            labelLayout.minHeight = RowHeight;

            labelLayout.preferredHeight = RowHeight;

            labelLayout.flexibleHeight = 0f;



            TextMeshProUGUI label = labelObject.AddComponent<TextMeshProUGUI>();

            ConfigureSuggestionLabel(label, PrimaryFontSize, PrimaryTextColor, TextAlignmentOptions.Center);

            label.text = title ?? string.Empty;

        }



        private static void CreateRowTextContent(
            Transform rowTransform,
            string title,
            bool hasSubtitle,
            string subtitle,
            float insetRight)
        {
            GameObject textArea = new GameObject("TextArea", typeof(RectTransform));
            textArea.transform.SetParent(rowTransform, false);

            RectTransform textRect = textArea.GetComponent<RectTransform>();
            StretchFull(textRect);

            if (insetRight > 0f)
            {
                textRect.offsetMax = new Vector2(-insetRight, 0f);
            }

            if (hasSubtitle)
            {
                CreateSubtitleRowContent(textArea.transform, title, subtitle);
            }
            else
            {
                CreateSingleLineRowContent(textArea.transform, title);
            }
        }

        private static bool TryCreateCategoryIconRight(
            Transform rowTransform,
            PartSuggestion suggestion,
            bool showPlaceholderWhenMissing)
        {
            StockCategorizerIconHelper.TryResolveLiveCategory(suggestion, out object liveCategory);

            CustomCategoryIconHelper.CategoryIconSource iconSource = CustomCategoryIconHelper.GetIconSource(
                suggestion.IconName,
                suggestion.FilterKey,
                liveCategory);

            if (!iconSource.IsValid && !showPlaceholderWhenMissing)
            {
                return false;
            }

            CreateCategoryIconRight(rowTransform, suggestion, liveCategory, iconSource, showPlaceholderWhenMissing);
            return iconSource.IsValid || showPlaceholderWhenMissing;
        }

        private static void CreateCategoryIconRight(
            Transform rowTransform,
            PartSuggestion suggestion,
            object liveCategory,
            CustomCategoryIconHelper.CategoryIconSource iconSource,
            bool showPlaceholderWhenMissing)
        {
            GameObject iconObject = new GameObject("CategoryIcon", typeof(RectTransform));
            iconObject.transform.SetParent(rowTransform, false);

            RectTransform iconRect = iconObject.GetComponent<RectTransform>();
            iconRect.anchorMin = new Vector2(1f, 0.5f);
            iconRect.anchorMax = new Vector2(1f, 0.5f);
            // Pivot on the right so negative X inset keeps the icon inside the row.
            // (pivot-left + positive X from a right anchor placed icons outside the viewport mask.)
            iconRect.pivot = new Vector2(1f, 0.5f);
            iconRect.anchoredPosition = new Vector2(-CategoryIconPadding, 0f);
            iconRect.sizeDelta = new Vector2(CategoryIconSize, CategoryIconSize);

            RawImage iconImage = iconObject.AddComponent<RawImage>();
            iconImage.raycastTarget = false;
            iconImage.enabled = true;
            iconObject.transform.SetAsLastSibling();

            if (iconSource.IsValid)
            {
                iconImage.texture = iconSource.Texture;
                iconImage.uvRect = iconSource.UvRect;
                iconImage.color = Color.white;
            }
            else if (showPlaceholderWhenMissing)
            {
                iconImage.texture = Texture2D.whiteTexture;
                iconImage.uvRect = new Rect(0f, 0f, 1f, 1f);
                iconImage.color = new Color(0.2f, 0.24f, 0.3f, 0.35f);
                EditorBootstrap.LogWarningOnce(
                    "categoryIcon." + suggestion.Kind + "." + (suggestion.FilterKey ?? suggestion.IconName ?? string.Empty),
                    "Category row icon missing for kind="
                    + suggestion.Kind
                    + " key='"
                    + (suggestion.FilterKey ?? string.Empty)
                    + "' icon='"
                    + (suggestion.IconName ?? string.Empty)
                    + "'.");
            }
        }

        private static void CreateSubtitleRowContent(Transform rowTransform, string title, string subtitle)

        {

            GameObject content = new GameObject("Content", typeof(RectTransform));

            content.transform.SetParent(rowTransform, false);

            StretchFull(content.GetComponent<RectTransform>());



            VerticalLayoutGroup contentLayout = content.AddComponent<VerticalLayoutGroup>();

            contentLayout.childAlignment = TextAnchor.MiddleCenter;

            contentLayout.childControlHeight = true;

            contentLayout.childControlWidth = true;

            contentLayout.childForceExpandHeight = false;

            contentLayout.childForceExpandWidth = true;

            contentLayout.spacing = 0f;

            contentLayout.padding = new RectOffset(4, 4, 2, 2);



            CreateRowLabel(content.transform, "Title", TitleLineHeight, PrimaryFontSize, PrimaryTextColor, title);

            CreateRowLabel(

                content.transform,

                "Subtitle",

                SubtitleLineHeight,

                SubtitleFontSize,

                SubtitleTextColor,

                subtitle,

                TextAlignmentOptions.Center);

        }



        private void CreateHistoryDismissButton(Transform rowTransform, PartSuggestion suggestion)
        {
            string query = suggestion.QueryText ?? suggestion.DisplayText ?? string.Empty;
            GameObject buttonObject = new GameObject("HistoryDismiss", typeof(RectTransform));
            buttonObject.transform.SetParent(rowTransform, false);

            RectTransform buttonRect = buttonObject.GetComponent<RectTransform>();
            buttonRect.anchorMin = new Vector2(1f, 0.5f);
            buttonRect.anchorMax = new Vector2(1f, 0.5f);
            buttonRect.pivot = new Vector2(1f, 0.5f);
            buttonRect.anchoredPosition = new Vector2(-4f, 0f);
            buttonRect.sizeDelta = new Vector2(HistoryDismissButtonSize, HistoryDismissButtonSize);

            Image buttonImage = buttonObject.AddComponent<Image>();
            buttonImage.sprite = GetWhiteSprite();
            buttonImage.color = new Color(0.18f, 0.22f, 0.28f, 1f);
            buttonImage.raycastTarget = true;

            GameObject labelObject = new GameObject("Label", typeof(RectTransform));
            labelObject.transform.SetParent(buttonObject.transform, false);
            StretchFull(labelObject.GetComponent<RectTransform>());

            TextMeshProUGUI label = labelObject.AddComponent<TextMeshProUGUI>();
            label.text = "X";
            label.fontSize = HeaderIconFontSize;
            label.lineSpacing = -2f;
            label.margin = Vector4.zero;
            label.fontStyle = FontStyles.Bold;
            label.alignment = TextAlignmentOptions.Center;
            label.color = HeaderIconTextColor;
            label.raycastTarget = false;

            RowHoverClickHandler hoverClick = buttonObject.AddComponent<RowHoverClickHandler>();
            hoverClick.Initialize(
                buttonImage,
                new Color(0.18f, 0.22f, 0.28f, 1f),
                new Color(0.35f, 0.2f, 0.2f, 1f),
                () => RequestHistoryDismiss(query));
            UiTooltipHelper.AttachTextTooltip(buttonObject, "Remove from history");
            buttonObject.transform.SetAsLastSibling();
        }

        private void RequestHistoryDismiss(string query)
        {
            EditorBootstrap.Log("History dismiss clicked: '" + (query ?? string.Empty) + "'.");
            OnHistoryItemDismissed?.Invoke(query);
        }

        private void HandleRowPointerClick(PartSuggestion suggestion)
        {
            string text = suggestion.DisplayText ?? suggestion.QueryText ?? string.Empty;
            EditorBootstrap.Log(
                "Row clicked: '"
                + text
                + "' kind="
                + suggestion.Kind
                + " key='"
                + (suggestion.FilterKey ?? string.Empty)
                + "'");
            OnSuggestionChosen?.Invoke(suggestion);
        }



        private void ClearRows()

        {

            foreach (GameObject row in _rowObjects)

            {

                if (row != null)

                {

                    Destroy(row);

                }

            }



            _rowObjects.Clear();



            if (_scrollRect != null)

            {

                _scrollRect.verticalNormalizedPosition = 1f;

            }

        }

    }

}

